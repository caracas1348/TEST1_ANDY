**Open XML SDK for JavaScript**
This is a small JavaScript library that enables you to implement Open XML functionality. Interesting platforms are:
* In-browser applications using IE, Chrome, FireFox, and other browsers.
* Server-side functionality using NodeJs.
* Windows 8 'Store' applications that are written in HTML5 and JavaScript.
* Word 2013 JavaScript Apps
* SharePoint 2013 JavaScript Apps.
* SharePoint 2010 JavaScript Web Parts.
Click on the [DOWNLOADS](DOWNLOADS)(https___openxmlsdkjs.codeplex.com_releases_view_108153) tab to download the ZIP file that contains all source code necessary to write Open XML applications in JavaScript.

You can find documentation and examples at the [Open XML SDK for JavaScript Resource Center](Open XML SDK for JavaScript Resource Center)(http___openxmldeveloper.org_wiki_w_wiki_open-xml-sdk-for-javascript.aspx)

Video: [Introduction to the Open XML SDK for JavaScript](Introduction to the Open XML SDK for JavaScript)(http___www.openxmldeveloper.org)

Release 1.01.02 (December 20, 2013)

* Added new example, examp10-open-xlsx.html, which shows loading a spreadsheet from a template string, making a modification to it, and then enabling the user to save the generated spreadsheet locally.

Release 1.01.01

* Fixed an issue where UTF8 characters were not serialized properly if the XDocument for a part was not loaded.

Release 1.01

* Perf improvement - opens and saves in 50% of the time.
* Added support for loading and saving blobs.
* In distribution, replaced jszip.js, jszip-load.js, jszip-inflate.js, jszip-deflate.js
* Added support for asynchronous loading and saving of blobs, flatOpc, and base64
* Added FileSaver.js to the zip.
* Added four examples
	* examp06-template-documents.html shows how to create a template document in string literals
	* examp07-load-save-via-html5.html shows one approach to using HTML5 to open/save local documents
	* examp08-load-save-via-html5-b.html shows a second approach to using HTML5 to open/save local documents
	* examp09-open-base64-async.html shows asynchronous opening / saving of documents

Release 1.0

Initial release.